package com.l4yn3.microserviceseclab.data;

import lombok.Data;

@Data
public class Teacher {
    private int id;
    private String name;
    private boolean sex;
}
